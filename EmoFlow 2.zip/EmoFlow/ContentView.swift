import SwiftUI

struct ContentView: View {
    @State private var absorbedEmotions: [EmotionType] = []
    @State private var showAlert = false

    var body: some View {
        ZStack {
            // 背景渐变
            LinearGradient(
                gradient: Gradient(colors: [Color.white, Color(hue: 0.6, saturation: 0.1, brightness: 1.0)]),
                startPoint: .top,
                endPoint: .bottom
            )
            .edgesIgnoringSafeArea(.all)

            VStack(spacing: 30) {
                Text("今天你的心情怎么样？")
                    .font(.title2)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                    .padding(.top, 20)

                // 气泡区域
                HStack(spacing: 24) {
                    ForEach(EmotionType.allCases, id: \.self) { emotion in
                        EmotionBubble(emotion: emotion)
                            .onDrag {
                                return NSItemProvider(object: emotion.rawValue as NSString)
                            }
                    }
                }

                // 心形容器
                ZStack {
                    HeartShape()
                        .fill(blendedColor(from: absorbedEmotions))
                        .shadow(color: blendedColor(from: absorbedEmotions).opacity(0.3), radius: 10)
                        .frame(width: 180, height: 160)
                        .overlay(HeartShape().stroke(Color.green, lineWidth: 3))
                        .scaleEffect(1.0 + Double(absorbedEmotions.count) * 0.02)
                        .animation(.spring(), value: absorbedEmotions)

                    HeartShape()
                        .fill(Color.clear)
                        .frame(width: 180, height: 160)
                        .contentShape(HeartShape())
                        .onDrop(of: [.text], isTargeted: nil) { providers in
                            if let provider = providers.first {
                                _ = provider.loadObject(ofClass: NSString.self) { value, _ in
                                    if let raw = value as? String,
                                       let emo = EmotionType(rawValue: raw) {
                                        DispatchQueue.main.async {
                                            absorbedEmotions.append(emo)
                                            print("🔥 当前情绪：", absorbedEmotions.map { $0.rawValue })
                                        }
                                    }
                                }
                            }
                            return true
                        }
                }

                // 发送按钮
                Button("记录我的心情") {
                    showAlert = true
                    sendToAI()
                }
                .padding(.horizontal, 30)
                .padding(.vertical, 12)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
                .font(.headline)

                Spacer()
            }
            .padding()
        }
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("已发送"),
                message: Text("当前情绪已作为参数传给 AI。"),
                dismissButton: .default(Text("知道了"))
            )
        }
    }

    func blendedColor(from emotions: [EmotionType]) -> Color {
        guard !emotions.isEmpty else { return Color.clear }

        var red: Double = 0
        var green: Double = 0
        var blue: Double = 0

        for emotion in emotions {
            switch emotion {
            case .angry: red += 1
            case .sad: blue += 1
            case .tired: red += 0.5; green += 0.5; blue += 0.5
            case .happy: red += 1; green += 1
            }
        }

        let count = Double(emotions.count)
        return Color(red: red / count, green: green / count, blue: blue / count)
    }

    func sendToAI() {
        let emotionCounts = Dictionary(grouping: absorbedEmotions, by: { $0 }).mapValues { $0.count }

        let moodDescription = EmotionType.allCases.map { type -> String in
            let count = emotionCounts[type, default: 0]
            return "\(type.rawValue): \(count)"
        }.joined(separator: ", ")

        print("🧠 发给 AI 的情绪参数：\n\(moodDescription)")
    }
}
