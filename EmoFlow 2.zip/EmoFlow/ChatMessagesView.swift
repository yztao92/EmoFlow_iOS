import SwiftUI

struct ChatMessagesView: View {
    let messages: [ChatMessage]
    let isLoading: Bool

    var body: some View {
        LazyVStack(alignment: .leading, spacing: 12) {
            ForEach(messages) { message in
                ChatBubble(
                    message: message.content,
                    isUser: message.role == .user
                )
                .padding(.horizontal)
            }

            if isLoading {
                HStack {
                    ProgressView().scaleEffect(0.8)
                    Text("对方正在输入…")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding(.horizontal)
            }
        }
        .padding(.vertical)
    }
}
