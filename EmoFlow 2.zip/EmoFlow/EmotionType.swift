import Foundation

enum EmotionType: String, CaseIterable {
    case angry, sad, tired, happy
}
