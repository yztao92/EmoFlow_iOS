import SwiftUI

struct ChatView: View {
    let moodScore: Double

    @State private var messages: [ChatMessage] = []
    @State private var inputText: String = ""
    @State private var isLoading = false
    @FocusState private var isInputFocused: Bool

    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    ChatMessagesView(messages: messages, isLoading: isLoading)
                        .onChange(of: messages.count) {
                            withAnimation {
                                proxy.scrollTo(messages.last?.id, anchor: .bottom)
                            }
                        }
                }
            }

            Divider()

            HStack {
                TextField("说点什么...", text: $inputText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .focused($isInputFocused)

                Button("发送") {
                    send()
                }
                .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding()
        }
        .navigationTitle("情绪对话")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            Task { await loadOpeningMessage() }
        }
    }

    private func loadOpeningMessage() async {
        isLoading = true
        do {
            let moodText: String

            switch moodScore {
            case let x where x >= 6:
                moodText = "听起来今天心情不错～有什么开心的事想记录一下吗？"
            case let x where x >= 5:
                moodText = "欢迎回来，我在这儿陪你聊聊。"
            default:
                moodText = "咋啦？又怎么了？我在呢～"
            }

            messages.append(ChatMessage(role: .assistant, content: moodText))
        }
        isLoading = false
    }
    
    private func send() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        // ✅ 防止自问自答的用户误输入
        if trimmed.lowercased().hasPrefix("user:") || trimmed.lowercased().hasPrefix("assistant:") {
            messages.append(ChatMessage(role: .assistant, content: "嘿，我们不用加 'user:' 或 'assistant:'，直接说出你的想法就好～"))
            inputText = ""
            return
        }

        let userMessage = ChatMessage(role: .user, content: trimmed)
        messages.append(userMessage)
        inputText = ""
        isLoading = true
        isInputFocused = false

        Task {
            do {
                let (answer, references) = try await ChatService.shared.sendMessage(
                    moodScore: moodScore,
                    messages: messages.map { ChatMessageDTO(role: $0.role.rawValue, content: $0.content) }
                )

                messages.append(ChatMessage(role: .assistant, content: answer, references: references))
            } catch {
                messages.append(ChatMessage(role: .assistant, content: "出错了，请重试"))
            }
            isLoading = false
        }
    }
}
